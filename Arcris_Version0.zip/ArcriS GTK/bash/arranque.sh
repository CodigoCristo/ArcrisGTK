#!/bin/bash

arranque=$( ls /sys/firmware/efi/ | grep -ic efivars )

if [ $arranque == 1 ]
then
echo "UEFI"
else
echo "BIOS LEGACY"
fi