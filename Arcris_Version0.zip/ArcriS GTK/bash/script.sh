#!/bin/sh

case "$1" in

"zonahoraria") 
printf $(curl https://ipapi.co/timezone)
;;

"ubica") 
printf $(curl https://ipapi.co/country_name)
;;

"idioma") 
printf $(curl https://ipapi.co/languages | awk -F "," '{print $1}')
;;

"idioma-sistema") 
cat text/locale.gen

;;

"teclado-sistema") 
cat text/localectlX11

;;

"teclado-terminal") 
cat text/localectlT

;;

"disk") 
echo "print devices" | parted | grep /dev/ | awk '{if (NR!=1) {print}}' | sed '/sr/d'

;;

"arranque") 
arranque=$( ls /sys/firmware/efi/ | grep -ic efivars )
if [ $arranque == 1 ]
then
echo "UEFI"
else
echo "BIOS LEGACY"
fi
;;



"tablapartition") 
diskselect="/dev/sdb (2000GB)"
disk=$(echo ${diskselect} | awk '{printf $1}')
diskgpt=$( fdisk -l ${disk} | grep -ic gpt )
diskmbr=$( fdisk -l ${disk} | grep -ic dos )
if [ $diskgpt == 1 ]
then
echo "GPT"

elif [ $diskmbr == 1 ]
then
echo "MBR"

else
echo "Sin definir"
fi
;;



"arranquemanual") 
arranque=$( ls /sys/firmware/efi/ | grep -ic efivars )
if [ $arranque == 1 ]
then
echo "SISTEMA UEFI"
else
echo "SISTEMA BIOS LEGACY"
fi
;;

"diskmanual") 
fdisk -l | grep /dev/ | grep ":" | awk '{if (NR=1) {print  $2, $3, $4}}' | sed -e 's/.$//'
echo "Seleccionar..."
;;


esac

#sudo fdisk -l | grep EFI | awk '{print $1,$6,$7}'
#sudo fdisk -l | grep /dev/ | awk '{if (NR!=1) {print}}' | sed 's/*//g' | awk -F ' ' '{print $1}' | grep /dev/ | awk '{if (NR=1) {print}}' | sed 's/*//g' | awk -F ' ' '{print $1}'

#cat /etc/locale.gen | grep ".UTF-8 UTF-8" | sed '1,4d' | sed 's/\(.\{1\}\)//'
#localectl list-x11-keymap-layouts | awk '$locales=$locales'
#localectl list-keymaps | awk '$locales=$locales'


# echo Idioma: $(curl https://ipapi.co/languages | awk -F "," '{print $1}')
# echo Ubicación: $(curl https://ipapi.co/country_name)/$(curl https://ipapi.co/region)

# Ejecutar un comando usando la variable guardada
# ejemplo
# commandline = g_strdup_printf("echo %s" , idioma_select);
# g_shell_parse_argv(commandline, NULL, &command, NULL);
# g_free(commandline);
# g_spawn_async(NULL, command, NULL, G_SPAWN_SEARCH_PATH|G_SPAWN_DO_NOT_REAP_CHILD, NULL, NULL, NULL, NULL);


#/////////////////////////////////////////////////////////////////////////////////
#// CSS
#// box-shadow: 5px 0px 10px 4px alpha(black, 0.40);
#// box-shadow: 0px 0px 2px 1px alpha(#1D1D1D, 10.50);
#// #1794D1
#// #1F4152
#// #080808  Tema
#// #0D0E13
#// #222B33
#// #1A1A1A
#/////////////////////////////////////////////////////////////////////////////////


#//gtk_combo_box_get_active(listwidget);
#//gtk_label_set_label(resultado, output);
#//printf("Active text: %s\n", text);

#// ¿Dónde quiere instalar Arch Linux?

#// utilizar todo el disco.
#// utilizar todo el disco y configurar LVM cifrado